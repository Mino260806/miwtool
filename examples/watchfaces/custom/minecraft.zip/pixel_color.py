from PIL import Image
import os

os.chdir("minutes")

def tranform(c):
	return int(255 - (255 - c) / 1.186046511627907)

for path in os.listdir():
	img = Image.open(path)
	pixels = img.load()
	for i in range(img.size[0]):
		for j in range(img.size[1]):
			pixel = pixels[i,j]
			pixels[i,j] = (*(tranform(c) for c in pixel[:3]), pixel[3])
	img.save(path)